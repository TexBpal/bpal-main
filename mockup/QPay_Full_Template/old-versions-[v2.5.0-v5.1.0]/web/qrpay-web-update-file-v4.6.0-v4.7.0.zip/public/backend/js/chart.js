
$(function() {
    $('#chart18').easyPieChart({
        size: 80,
        barColor: '#f05050',
        scaleColor: false,
        lineWidth: 5,
        trackColor: '#ff9f43',
        lineCap: 'circle',
        animate: 3000
    });
  });
$(function() {
    $('#chart19').easyPieChart({
        size: 80,
        barColor: '#f05050',
        scaleColor: false,
        lineWidth: 5,
        trackColor: '#1e9ff2',
        lineCap: 'circle',
        animate: 3000
    });
  });
$(function() {
    $('#chart20').easyPieChart({
        size: 80,
        barColor: '#f05050',
        scaleColor: false,
        lineWidth: 5,
        trackColor: '#28c76f',
        lineCap: 'circle',
        animate: 3000
    });
  });
$(function() {
    $('#chart21').easyPieChart({
        size: 80,
        barColor: '#f05050',
        scaleColor: false,
        lineWidth: 5,
        trackColor: '#5a5278',
        lineCap: 'circle',
        animate: 3000
    });
  });
