@include('admin.components.data-table.cash-pickup-table',compact("cashPickups"))
