@include('agent.components.transaction-log',compact("transactions"))
