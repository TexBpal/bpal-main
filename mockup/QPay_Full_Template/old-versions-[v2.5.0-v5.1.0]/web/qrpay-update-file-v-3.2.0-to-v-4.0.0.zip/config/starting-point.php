<?php

return [
    'status'    => false,
    'point'     => '/',
];