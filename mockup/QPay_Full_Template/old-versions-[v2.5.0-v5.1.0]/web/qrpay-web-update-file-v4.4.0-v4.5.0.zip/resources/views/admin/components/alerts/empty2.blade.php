<tr>
    <td colspan="{{ $colspan ?? "" }}" class="p-0 d-table-cell"><div class="alert alert-primary d-flex justify-content-center mb-0 w-100">{{ __("No data found!") }}</div></td>
</tr>
