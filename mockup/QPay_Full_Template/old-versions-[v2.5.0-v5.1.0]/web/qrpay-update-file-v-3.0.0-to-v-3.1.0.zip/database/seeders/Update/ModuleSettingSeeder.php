<?php

namespace Database\Seeders\Update;

use App\Constants\ModuleSetting;
use App\Models\Admin\ModuleSetting as AdminModuleSetting;
use Illuminate\Database\Seeder;

class ModuleSettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {


         //make module for merchant
        $data = [
            ModuleSetting::MERCHANT_PAY_LINK  => 'Merchant Pay Link'
        ];
        $create = [];
        foreach($data as $slug => $item) {
            $create[] = [
                'admin_id'          => 1,
                'slug'              => $slug,
                'user_type'         => "MERCHANT",
                'status'            => true,
                'created_at'        => now(),
            ];
        }
        AdminModuleSetting::insert($create);
    }
}
