<?php

namespace Database\Seeders\Update;

use Illuminate\Database\Seeder;
use App\Models\Admin\PaymentGateway;
use App\Models\Admin\PaymentGatewayCurrency;

class PaymentGatewaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //gateway data
        $last_gateway = PaymentGateway::latest()->first();
        if(!PaymentGateway::where('alias','coingate')->exists()){
            $payment_gateways_id = $last_gateway->id+1;
            $payment_gateways_code = PaymentGateway::max('code')+5;

            $payment_gateways = array(
                array('id' => $payment_gateways_id,'slug' => 'add-money','code' =>  $payment_gateways_code,'type' => 'AUTOMATIC','name' => 'CoinGate','title' => 'Crypto Payment gateway (CoinGate)','alias' => 'coingate','image' => '1e3e7e01-8ffa-46ec-9bcd-bc63501192e7.webp','credentials' => '[{"label":"Sandbox URL","placeholder":"Enter Sandbox URL","name":"sandbox-url","value":"https:\\/\\/api-sandbox.coingate.com\\/v2"},{"label":"Sandbox App Token","placeholder":"Enter Sandbox App Token","name":"sandbox-app-token","value":"XJW4RyhT8F-xssX2PvaHMWJjYe5nsbsrbb2Uqy4m"},{"label":"Production URL","placeholder":"Enter Production URL","name":"production-url","value":"https:\\/\\/api.coingate.com\\/v2"},{"label":"Production App Token","placeholder":"Enter Production App Token","name":"production-app-token","value":null}]','supported_currencies' => '["USD","BTC","LTC","ETH","BCH","TRX","ETC","DOGE","BTG","BNB","TUSD","USDT","BSV","MATIC","BUSD","SOL","WBTC","RVN","BCD","ATOM","BTTC","EURT"]','crypto' => '0','desc' => NULL,'input_fields' => NULL,'status' => '1','last_edit_by' => '1','created_at' => '2023-11-19 12:02:05','updated_at' => '2023-11-19 12:04:50','env' => 'SANDBOX')
            );
            PaymentGateway::insert($payment_gateways);

            $payment_gateway_currencies = array(
                array('payment_gateway_id' =>   $payment_gateways_id,'name' => 'CoinGate USDT','alias' => 'coingate-usdt-automatic','currency_code' => 'USDT','currency_symbol' => '$','image' => NULL,'min_limit' => '1.00000000','max_limit' => '100.00000000','percent_charge' => '1.00000000','fixed_charge' => '0.00000000','rate' => '1.00000000','created_at' => '2023-11-19 12:04:50','updated_at' => '2023-11-19 12:04:50'),
                array('payment_gateway_id' =>   $payment_gateways_id,'name' => 'CoinGate USD','alias' => 'coingate-usd-automatic','currency_code' => 'USD','currency_symbol' => '$','image' => NULL,'min_limit' => '1.00000000','max_limit' => '1000.00000000','percent_charge' => '1.00000000','fixed_charge' => '0.00000000','rate' => '1.00000000','created_at' => '2023-11-19 12:04:50','updated_at' => '2023-11-19 12:04:50')
            );
            PaymentGatewayCurrency::insert($payment_gateway_currencies);

        }

    }
}
