<<<<<<<< Update Guide >>>>>>>>>>>

Immediate Older Version: 3.0.0
Current Version: 3.1.0

Feature Update:
1. PayLink For Merchant (Web & Api).
2. Update Payment Gateway Seeder




Please Use This Commands On Your Terminal To Update Full System
1. To Run project Please Run This Command On Your Terminal
    composer update && composer dumpautoload && php artisan migrate

2.  php artisan db:seed --class=Database\\Seeders\\Update\\AppSettingsSeeder
    php artisan db:seed --class=Database\\Seeders\\Update\\BasicSettingsSeeder
    php artisan db:seed --class=Database\\Seeders\\Update\\ModuleSettingSeeder
    php artisan db:seed --class=Database\\Seeders\\Update\\PaymentGatewaySeeder

