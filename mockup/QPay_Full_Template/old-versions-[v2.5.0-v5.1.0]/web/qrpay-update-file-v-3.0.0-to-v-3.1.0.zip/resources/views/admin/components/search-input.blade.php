<div class="table-search-wrapper">
    <div class="position-relative">
        <input class="form-control" type="text" placeholder="Search" aria-label="Search" name="{{ $name ?? "" }}">
        <span class="las la-search"></span>
    </div>
</div>
