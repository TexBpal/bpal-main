@extends('admin.layouts.master')

@push('css')
@endpush

@section('page-title')
    @include('admin.components.page-title', ['title' => __($page_title)])
@endsection

@section('breadcrumb')
    @include('admin.components.breadcrumb', [
        'breadcrumbs' => [
            [
                'name' => __('Dashboard'),
                'url' => setRoute('admin.dashboard'),
            ],
        ],
        'active' =>  __($page_title),
    ])
@endsection

@section('content')
    <div class="custom-card">
        <div class="card-header">
            <h6 class="title">{{  __($page_title) }}</h6>
        </div>
        <div class="card-body">
            <form class="card-form">
                <div class="row align-items-center mb-10-none">
                    <div class="col-xl-4 col-lg-4 form-group">
                        <ul class="user-profile-list-two">
                            <li class="one">Date: <span>{{ dateFormat('d M y h:i:s A', $data->created_at) }}</span></li>
                            <li class="two">TRX ID: <span>{{ @$data->trx_id }}</span></li>
                            <li class="three">Email: <span>
                                @if($data->user_id != null)
                                    <a href="{{ setRoute('admin.users.details',$data->creator->username) }}">{{ $data->creator->email }} ({{ __("USER") }})</a>
                                @elseif($data->merchant_id != null)
                                    <a href="{{ setRoute('admin.merchants.details',$data->creator->username) }}">{{ $data->creator->email }} ({{ __("MERCHANT") }})</a>
                                @endif
                                </span></li>
                            <li class="four">Method: <span>{{ @$data->type }}</span></li>
                            <li class="five">Amount: <span>{{ get_amount(@$data->request_amount,null,4) }} {{ @$data->details->charge_calculation->sender_cur_code }}</span></li>
                        </ul>
                    </div>
                    <div class="col-xl-4 col-lg-4 form-group">
                        <div class="user-profile-thumb">
                            <img src="{{ @$data->user->userImage }}" alt="payment">
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 form-group">
                        <ul class="user-profile-list two">
                            <li class="one">Charge: <span>{{ get_amount(@$data->charge->total_charge,null,4) }} {{ @$data->details->charge_calculation->sender_cur_code }}</span></li>
                            <li class="two">After Charge: <span>{{ get_amount(@$data->payable,null,4) }} {{ @$data->details->charge_calculation->sender_cur_code }}</span></li>
                            <li class="four">Conversion Payable: <span>{{ get_amount(@$data->details->charge_calculation->conversion_payable,@$data->details->charge_calculation->receiver_currency_code,4) }}</span></li>
                            <li class="three">Rate: <span>1 {{ get_default_currency_code() }} = {{ get_amount(@$data->details->sender_currency->rate,@$data->details->sender_currency->currency_code,4) }} {{ @$data->currency->currency_code }}</span></li>
                            <li class="five">Status:  <span class="{{ @$data->stringStatus->class }}">{{ @$data->stringStatus->value }}</span></li>
                        </ul>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="custom-card mt-15">
        <div class="card-header">
            <h6 class="title text-bold">{{ __("Payment Information") }}</h6>
        </div>
        <div class="card-body">
            <ul class="product-sales-info">
                <li>
                    <span class="kyc-title">{{ __("Sender Email") }}:</span>
                    <span>{{ @$data->details->email }}</span>
                </li>
                <li>
                    <span class="kyc-title">{{ __("Card Holder Name") }}:</span>
                    <span>{{ @$data->details->card_name }}</span>
                </li>
                <li>
                    <span class="kyc-title">{{ __("Sender Card Number") }}:</span>
                    <span>**** **** **** {{ @$data->details->last4_card }}</span>
                </li>
            </ul>
        </div>
    </div>

@endsection
@push('script')
@endpush
