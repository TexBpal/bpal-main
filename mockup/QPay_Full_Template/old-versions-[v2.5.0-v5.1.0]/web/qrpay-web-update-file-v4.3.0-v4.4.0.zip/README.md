<<<<<<<< Update Guide >>>>>>>>>>>

Immediate Older Version: 4.3.0
Current Version: 4.4.0

Feature Update:
1. CDN and Assets.
2. Qr-Code Generation Issues Fixed.
3. Removed Strowallet Virtual Card System.



Please Use This Commands On Your Terminal To Update Full System
1. To Run project Please Run This Command On Your Terminal
    composer update && composer dumpautoload && php artisan view:clear

2. To Update Web & App Version Please Run This Command On Your Terminal
    php artisan db:seed --class=Database\\Seeders\\Update\\AppSettingsSeeder
    php artisan db:seed --class=Database\\Seeders\\Update\\BasicSettingsSeeder

