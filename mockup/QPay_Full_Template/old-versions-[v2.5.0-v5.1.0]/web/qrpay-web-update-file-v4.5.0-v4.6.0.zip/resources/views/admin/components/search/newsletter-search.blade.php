@include('admin.components.data-table.newsletter-table',compact("data"))
