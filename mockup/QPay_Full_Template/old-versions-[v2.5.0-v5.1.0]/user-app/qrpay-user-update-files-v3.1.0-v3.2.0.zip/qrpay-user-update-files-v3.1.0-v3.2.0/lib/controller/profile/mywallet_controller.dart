import 'package:get/get.dart';

class MywalletController extends GetxController{
  RxInt selected=0.obs;
}