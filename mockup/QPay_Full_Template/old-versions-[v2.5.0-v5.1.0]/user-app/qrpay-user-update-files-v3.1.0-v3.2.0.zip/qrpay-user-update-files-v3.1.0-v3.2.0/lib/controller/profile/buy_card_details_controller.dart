import 'package:get/get.dart';

class BuyCardDetailsController extends GetxController {
  RxInt count = 1.obs;
}
