
// import 'package:get/get.dart';

// class  ScanQrController extends GetxController{
 

// //  final qrKey = GlobalKey(debugLabel: 'QR');
// //   QRViewController? controller;
// //   Barcode? barcode;
// //   RxBool isVisible = true.obs;

// //   @override
// //   void dispose() {
// //     controller?.dispose();
// //     super.dispose();
// //   }

// //   // In order to get hot reload to work we need to pause the camera if the platform
// //   // is android, or resume the camera if the platform is iOS.
// //   @override
// //   void reassemble() async {
// //     super.reassemble();
// //     if (Platform.isAndroid) {
// //       await controller!.pauseCamera();
// //     } else if (Platform.isIOS) {
// //       controller!.resumeCamera();
// //     }
// //   }

// //   void readQr() async {
// //     if (barcode != null) {
// //       controller!.pauseCamera();
// //       controller!.dispose();
// //     }
// //   }
// }
